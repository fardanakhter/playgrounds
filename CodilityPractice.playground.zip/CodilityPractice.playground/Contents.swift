import UIKit

//public func solution(_ A : inout [Int]) -> Int {
//
//    var test = [Int: Int]()
//    var max = 1
//    for a in A {
//        if a > 0{
//            if max < a {max = a}
//
//            if test[a] == nil { test[a] = 1}
//            else { test[a]! += 1 }
//        }
//    }
//
//    for k in (0...max) {
//        if k > 0 && (test[k] ?? 0) == 0 { return k }
//    }
//
//    return max + 1
//}
//
//var test = [1,2,4]
//solution(&test)

//TopTal//
//public func solution(_ message : inout String, _ K : Int) -> String {
//
//    let letter = Array(message)
//    if K > letter.count { return message}
//
//    let splitBySpace = message.split(separator: " ")
//    let croppedIndex = message.index(message.startIndex, offsetBy: K)
//
//    print(splitBySpace)
//    print(message[..<croppedIndex])
//
//    let cropped = message[..<croppedIndex]
//    var croppedWords = cropped.split(separator: " ")
//    var ans = ""
//
//    let lastword = String(croppedWords.reversed().first ?? "")
//    if !splitBySpace.contains(Substring(lastword)){
//        croppedWords.removeLast()
//        croppedWords.forEach{
//            ans += "\($0) "
//        }
//        ans.removeLast()
//    }
//
//    return ans == "" ? "\(cropped)" : "\(ans)"
//}

//var test = "The quick brown fox jumps over the lazy dog"
//solution(&test, 39)

//def
//golden_max_slice(A):
//max_ending = max_slice = 0 for a in A:
//max_ending = max(0, max_ending + a)
//max_slice = max(max_slice, max_ending) return max_slice

//public func solution(_ P : inout [Int], _ S : inout [Int]) -> Int {
//
//    var total_p = 0
//    var total_s = 0
//    var counter = 0
//    S = S.sorted().reversed()
//    let n = P.count
//
//    for a in (0..<n) {
//        total_p += P[a]
//    }
//
//    for a in S {
//        total_s += a
//        counter += 1
//        if total_s >= total_p {return counter}
//    }
//    return P.count
//}

//var p = [2,3,4,2]
//var s = [2,5,7,2]
//solution(&p, &s)


//public func solution(_ A : inout [Int]) -> Int {
//    let totalToHalf = A.reduce(0) { return $0 + $1 } / 2
//    print(totalToHalf)
//    var count = 0
//
//    while true {
//        A = A.sorted().reversed()
//        A[0] = A[0] / 2
//        count += 1
//        var total = 0
//        for a in A {
//            total += a
//        }
//        if total <= totalToHalf { return count}
//    }
//    return 1
//}
//
//var test = [1,2]
//solution(&test)


// Find Leader problem

//func solution(_ arr: [Int]) -> Int{
//
//    var dict = [Int:Int]()
//
//    let l = arr.count / 2
//
//    for a in arr {
//        if dict[a] == nil { dict[a] = 0 }
//
//        dict[a]! += 1
//
//        if dict[a]! > l { return a }
//    }
//
//    print(dict)
//
//    return -1
//}
//
//solution([6,8,4,6,8,6,6])

// Passing cars

//public func solution(_ A : inout [Int]) -> Int {
//    if !A.contains(0) { return 0 }
//    var pairs = 0
//    var zeros = 0
//
//    A.forEach{
//        if $0 == 0 { zeros += 1 }
//        else { pairs += (1 * zeros) }
//    }
//    pairs = pairs > 1000000000 ? -1 : pairs
//    return pairs
//}
//
//var test = [0,1,0,1,1]
//solution(&test)

// Contact Name from Phone Dialer

//public func solution(_ A : inout [String], _ B : inout [String], _ P : String) -> String {
//
//    let n = A.count
//    //var contact = [Int: String]()
//    var result = [String]()
//
//    for i in (0..<n) {
//        let name = A[i]
//        let num = B[i]
//        //contact[num] = name
//        if "\(num)".contains(P) {
//            result.append(name)
//        }
//    }
//
//    if let ans = result.sorted().first {
//        return ans
//    }
//
//    return "NO CONTACT"
//}
// TEST CASE 01
//var test_a = ["pim", "pom"]
//var test_b = ["999999999", "777888999"]
//var test_p = "88999"

// TEST CASE 02
//var test_a = ["sander", "amy", "ann", "michae!"]
//var test_b = ["123456789", "234567890","789123456", "123123123"]
//var test_p = "1"

// TEST CASE 03
//var test_a = ["adam", "eva", "leo"]
//var test_b = ["121212121", "711111111", "444555666"]
//var test_p = "112"
//
//solution(&test_a, &test_b, test_p)

//Graph Problem
//public func solution(_ N: Int, A : inout [Int], B : inout [Int]) -> Bool {
//    
//    let graph = Graph<Int>()
//    let count = A.count
//    
//    for i in (0..<count) { // O(n)
//        let v1 = Graph<Int>.Vertex(value: A[i])
//        let v2 = Graph<Int>.Vertex(value: B[i])
//        
//        graph.addVertex(vertex: v1)
//        graph.addVertex(vertex: v2)
//        graph.addEdge(source: v1, destination: v2)
//    }
//
//    print(graph.description)
//    
//    var currentVertex = 1
//    guard var v1 = graph.getVertex(value: currentVertex) else { return false }
//    
//    while currentVertex != N {
//        
//        let nextVertex = currentVertex + 1
//        guard let v2 = graph.getVertex(value: nextVertex) else { return false }
//        
//        if let _ = graph.adjacencyDict[v1]?.first(where: { $0.destination == v2}) {
//            currentVertex += 1
//            v1 = v2
//        } else {
//            return false
//        }
//    }
//    return true
//}
//
//let N = 4
//var A = [1, 2, 4, 4, 3]
//var B = [2, 3, 1, 3, 1]
//
////let N = 4
////var A = [1, 2, 1, 3]
////var B = [2, 4, 3, 4]
//           
////let N = 6
////var A = [2, 4, 5, 3]
////var B = [3, 5, 6, 4]
//solution(N, A: &A, B: &B)

