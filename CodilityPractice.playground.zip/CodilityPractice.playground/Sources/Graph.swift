import Foundation

public class Graph<T: Hashable> {
    
    public init(){}
    public var adjacencyDict: [Vertex<T>: [Edge<T>]] = [:]
    
    public struct Vertex<T: Hashable>: Hashable {
        public let value: T
        
        public init(value: T) {
            self.value = value
        }
        
        public static func == (lhs: Vertex<T>, rhs: Vertex<T>) -> Bool{
            lhs.value == rhs.value
        }
        
        public var hashValue: Int {
            "\(value)".hashValue
        }
        
        public func hash(into hasher: inout Hasher) {
            hasher.combine(value)
        }
    }
    
    public struct Edge<T: Hashable>: Hashable {
        public let source: Vertex<T>
        public let destination: Vertex<T>
        
        public var hashValue: Int {
            "\(source)/\(destination)".hashValue
        }
        
        public func hash(into hasher: inout Hasher) {
            hasher.combine(source)
            hasher.combine(destination)
        }
    }
    
    public func addVertex(vertex: Vertex<T>){
        if adjacencyDict[vertex] == nil {
            adjacencyDict[vertex] = []
        }
    }
    
    public func getVertex(value: T) -> Vertex<T>? {
        adjacencyDict.keys.first{ $0.value == value }
    }
    
    // undirectional
    public func addEdge(source: Vertex<T>, destination: Vertex<T>){
        let edge1 = Edge(source: source, destination: destination)
        adjacencyDict[source]?.append(edge1)
        let edge2 = Edge(source: destination, destination: source)
        adjacencyDict[destination]?.append(edge2)
    }
    
    public var description: CustomStringConvertible {
        var result = ""
        for (vertex, edges) in adjacencyDict {
            var edgeString = ""
            edges.forEach{
                edgeString.append("\($0.destination) ")
            }
            result.append("\(vertex) ---> [ \(edgeString) ] \n ")
        }
        return result
    }
}
