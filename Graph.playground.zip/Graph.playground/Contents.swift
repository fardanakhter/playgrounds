import UIKit

class Graph<T: Hashable> {
    
    var adjacencyDict: [Vertex<T>: [Edge<T>]] = [:]
    
    struct Vertex<T: Hashable>: Hashable {
        let value: T
        
        static func == (lhs: Vertex<T>, rhs: Vertex<T>) -> Bool {
            lhs.value == rhs.value
        }
        
        var hashValue: Int {
            "\(value)".hashValue
        }
        
        func hash(into hasher: inout Hasher) {
            hasher.combine(value)
        }
    }
    
    struct Edge<T: Hashable>: Hashable {
        let source: Vertex<T>
        let destination: Vertex<T>
        
        var hashValue: Int {
            "\(source)/\(destination)".hashValue
        }
        
        func hash(into hasher: inout Hasher) {
            hasher.combine(source)
            hasher.combine(destination)
        }
    }
    
    func addVertex(vertex: Vertex<T>){
        if adjacencyDict[vertex] == nil {
            adjacencyDict[vertex] = []
        }
    }
    
    func getVertex(value: T) -> Vertex<T>? {
        adjacencyDict.keys.first{ $0.value == value }
    }
    
    // undirectional
    func addEdge(source: Vertex<T>, destination: Vertex<T>){
        let edge1 = Edge(source: source, destination: destination)
        adjacencyDict[source]?.append(edge1)
        let edge2 = Edge(source: destination, destination: source)
        adjacencyDict[destination]?.append(edge2)
    }
    
    public var description: CustomStringConvertible {
        var result = ""
        for (vertex, edges) in adjacencyDict {
            var edgeString = ""
            edges.forEach{
                edgeString.append("\($0.destination) ")
            }
            result.append("\(vertex) ---> [ \(edgeString) ] \n ")
        }
        return result
    }
}
