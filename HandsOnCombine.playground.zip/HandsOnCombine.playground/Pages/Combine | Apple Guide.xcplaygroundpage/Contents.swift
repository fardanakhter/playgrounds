import UIKit
import Combine
import Darwin

/* Replacing Closure as property pattern with Combine based Subject pattern */
print("*****  Closure as property pattern  *****")

@objc protocol Demonstratable{
    @objc optional var closureProperty: (() -> Void) { get set }
}

// Code demo with old closure property pattern
class ClassWithClosureProperty: Demonstratable {
    var closureProperty: (() -> Void) = {}
}

let instance = ClassWithClosureProperty()
instance.closureProperty = { print("we are now inside old closure property pattern") }

// Code demo with new combine subject pattern
class ClassWithSubject: Demonstratable {
    
    /*
     PassthroughSubject = This instance hold no current value and only publishes when subsctiber is subscribed
     CurrentValueSubject = This instance hold its current value and provides latest value to subscribers
     */
    
    //private let property = PassthroughSubject<String, Never>()
    private let property = CurrentValueSubject<String, Never>("somevalue")
    public var publisher: AnyPublisher<String, Never>
    
    init(){ publisher = property.eraseToAnyPublisher() }
    
    func publish(){ property.send(property.value); }
}

let instanceWithSubject = ClassWithSubject()
let subscriber1 = instanceWithSubject.publisher.sink { val in
    print("inside subscriber 1: \(val)")
}

let subscriber2 = instanceWithSubject.publisher.sink { val in
    print("inside subscriber 2: \(val)")
}
instanceWithSubject.publish()
subscriber1.cancel()
instanceWithSubject.publish()


print("\n\n")






/* Replacing Closure as Completion Handler pattern with Combine based Future.Promise pattern */
print("*****  Closure as completion handler pattern  *****")

class DemoAsyncOperationClass{
    func performAsyncOperationWithClosure(_ completion: @escaping ((String) -> Void)){
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            completion("somevalue after async completion")
        }
    }
    
    func performAsyncOperationWithCombine() -> Future<String, Never> {
        return Future(){ promise in
            DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                promise(.success("somevalue after async completion from Combine"))
            }
        }
    }
}

let asyncOperationInstance = DemoAsyncOperationClass()
asyncOperationInstance.performAsyncOperationWithClosure { val in
    //print(val)
}
let subs = asyncOperationInstance.performAsyncOperationWithCombine()
    .map{ [Character]($0) } // Combine operator: changing the type of data subscriber receives with ease and maintainable code
    .sink { val in
    //print(val)
}






/* Replacing KVO pattern with Combine pattern */
print("*****  KVO pattern  *****")

class UserData: NSObject{
    @objc dynamic var lastChekin: Date = Date()
}

let user = UserData()
print("current value: \(user.lastChekin)")

// adding KVO to the key of our instance in non-Combine way
let observation = user.observe(\.lastChekin, options: .new) { user, change in
    print("non-Combine way: \(change.newValue)")
}

// adding KVO to the key of our instance in Combine way
let cancellableSubscriber = user.publisher(for: \.lastChekin, options: .new)
    .filter{ date in
        //return date > Date(timeIntervalSinceNow: 1.0)  // adding any filter condition is made easy useing COMBINE operators
        return true
    }
    .sink { newValue in
    print("Combine way: \(newValue)")
    }

user.lastChekin = Date()


print("\n\n")






/* Replacing NotificationCenter observer pattern with Combine pattern */
print("*****  Notification Center pattern  *****")

// NON-Combine Way
let notificationName = NSNotification.Name(rawValue: "DemoNotification")
let object = NotificationCenter.default.addObserver(forName: notificationName, object: nil, queue: .main) { _ in
    print("Inside notification observer with non-Combine way")
}

// Combine way
let cancellable = NotificationCenter.default.publisher(for: notificationName, object: nil)
    .sink { _ in
        print("Inside notification observer with Combine way")
    }

NotificationCenter.default.post(name: notificationName, object: nil)
