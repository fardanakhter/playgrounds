import Foundation
import Combine
import UIKit

// Combining 2 publishers together for collective results

// Example
let subject1 = PassthroughSubject<String, Never>()
let subject2 = PassthroughSubject<String, Never>()

let publisher = Publishers.CombineLatest(subject1, subject2)

let subscriber = publisher.sink { (val1, val2) in
    print(val1 + " " + val2)
}

subject1.send("abc")
subject2.send("123")

subject1.send("fardan")
subject2.send("akhter")

// Combine with MVVM
final class FormViewModel {
    @Published var isSubmitAllowed: Bool = false
}

final class FormViewController: UIViewController {
    
    // switchSubscriber calls cancel() when FormViewController instance is removed from memory
    private var switchSubscriber: AnyCancellable?
    // can store all subscribers together as an array , using store() on subscriber
    private var subscribers: [AnyCancellable] = []
    private var viewModel = FormViewModel()

    @IBOutlet private weak var acceptTermsSwitch: UISwitch!
    @IBOutlet private weak var submitButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // storing single subscriber as property
        switchSubscriber = viewModel.$isSubmitAllowed
            .receive(on: DispatchQueue.main)
            .assign(to: \.isEnabled, on: submitButton)
            
        // OR
        
        // store multiple subscribers as list property
        viewModel.$isSubmitAllowed
            .receive(on: DispatchQueue.main)
            .assign(to: \.isEnabled, on: submitButton)
            .store(in: &subscribers)
    }

    @IBAction func didSwitch(_ sender: UISwitch) {
        viewModel.isSubmitAllowed = sender.isOn
    }
}

