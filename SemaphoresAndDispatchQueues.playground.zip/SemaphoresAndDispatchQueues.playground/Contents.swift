import UIKit

let statement01 = "First Statement!"
let statement02 = "Second Statement!"
let statement03 = "Third Statement!"
let statement04 = "Fourth Statement!"

let array = [statement01,statement02,statement03,statement04]

//This simulates API scenario by delay of random secs
func simulateAPI(_ statement: String,_ completion: @escaping () -> Void){
    
    let randomTime = Double.random(in: 1.0...5.0)
    DispatchQueue.main.asyncAfter(deadline: .now() + randomTime){
        print(statement)
        semaphore.signal()
    }
    semaphore.wait()
}

var semaphore = DispatchSemaphore(value: 0)  // wait and signal must be from seperate threads

/* Serial Approach */

//....1 .... 2.....3....4

//DispatchQueue.global().async {
//    array.forEach{ statement in
//        print("next")
//        simulateAPI(statement, {})
//    }
//}

/* Concurrent Approach */

//    ...1
//    ......2
//    ....3
//    .....4

//Note:- Semaphore has no effect in this approach as each wait is in new thread 

//array.forEach{ statement in
//    DispatchQueue.global().async {
//        simulateAPI(statement, {})
//    }
//}







