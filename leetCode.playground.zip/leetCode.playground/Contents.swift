import UIKit
//****  ****    ****    *****   *****   ****//
public class ListNode {
    public var val: Int
    public var next: ListNode?
    public init() { self.val = 0; self.next = nil; }
    public init(_ val: Int) { self.val = val; self.next = nil; }
    public init(_ val: Int, _ next: ListNode?) { self.val = val; self.next = next;}
}


func deleteDuplicates(_ head: ListNode?) -> ListNode? {
    var i = head
    while let _ = i?.next{
        i!.next = nextUnrepeatedNode(i)
        i = i?.next
    }

    return head
}

func nextUnrepeatedNode(_ n: ListNode?) -> ListNode?{
    guard let this = n else {return nil}
    guard let next = this.next else {return nil}

    if this.val != next.val {return next}
    else{
        return nextUnrepeatedNode(next)
    }
}

func returnLinkedList(_ l: ListNode?) -> [Int]{
    var a = [Int]()
    var i = l
    while let n = i {
        a.append(n.val)
        i = i?.next
    }
    return a
}

let test: ListNode? = ListNode(1)
test?.next = ListNode(1)
test?.next?.next = ListNode(1)
//test?.next?.next?.next = ListNode(3)

let test2: ListNode? = ListNode()
let test3: ListNode? = nil

let input = test
print("input: ", returnLinkedList(input))
let output = deleteDuplicates(input)
print("output:", returnLinkedList(output))
//****  ****    ****    *****   *****   ****//

//****  ****    ****    *****   *****   ****//
func removeDuplicates(_ nums: inout [Int]) -> Int {

    var map = [Int: Int]()
    var counter = 0

    for (_, i) in nums.enumerated(){

        if let _ = map[i] {
            counter += 1
        }
        else{ map[i] = 1 }
    }

    nums = Array(map.keys).sorted()
    nums.append(contentsOf: Array(repeating: 0, count: counter))

    return Array(map.keys).count
}

var test123 = [1,1,2,2,3,3]
let a = removeDuplicates(&test123)
print(a)
//****  ****    ****    *****   *****   ****//

//****  ****    ****    *****   *****   ****//
func plusOne(_ digits: [Int]) -> [Int] {
    
    var reversed = Array(digits.reversed())
    var carry = 1
    for (i, _) in reversed.enumerated() {
        reversed[i] += carry
        
        if reversed[i] > 9 {
            carry = 1
            reversed[i] %= 10
        }
        else{
            carry = 0
        }
    }
    
    if carry == 1 { reversed.append(1) }
    return reversed.reversed()
}

plusOne([9,9,9])
//****  ****    ****    *****   *****   ****//

//****  ****    ****    *****   *****   ****//

func canConstruct(_ ransomNote: String, _ magazine: String) -> Bool {
    var ref = Array(ransomNote)
    var compare = Array(magazine)
    
    Array(ransomNote).forEach{
        if compare.contains($0){
            compare[compare.firstIndex(of: $0)!] = "_"
            ref[ref.firstIndex(of: $0)!] = "_"
        }
    }
    
    print(ref)
    return ref.allSatisfy{ $0 == "_" }
}

canConstruct("aab", "baaa")
//****  ****    ****    *****   *****   ****//

public class TreeNode {
     public var val: Int
      public var left: TreeNode?
      public var right: TreeNode?
      public init() { self.val = 0; self.left = nil; self.right = nil; }
      public init(_ val: Int) { self.val = val; self.left = nil; self.right = nil; }
      public init(_ val: Int, _ left: TreeNode?, _ right: TreeNode?) {
          self.val = val
          self.left = left
          self.right = right
      }
}

func bstFromPreorder(_ preorder: [Int]) -> TreeNode? {
    
    let root = TreeNode(preorder[0])
    
    for i in 1..<(preorder.count) {
        let now = TreeNode(preorder[i])

        var keepSerching = true
        var ref = root
        
        while keepSerching {
            if now.val < ref.val{
                if ref.left == nil { ref.left = now; keepSerching = false }
                else { ref = ref.left! }
            }
            else{
                if ref.right == nil { ref.right = now; keepSerching = false }
                else { ref = ref.right! }
            }
        }
        
    }
    
    return root
}
bstFromPreorder([8,5,1,7,10,12])

//N L R
//                8
//            5
//        1       7

// ********************* *********************** *************** //
let singlesRomanMap: [String: Int] = ["I": 1,
                                      "V": 5,
                                      "X": 10,
                                      "L": 50,
                                      "C": 100,
                                      "D":500,
                                      "M": 1000]

let doublesRomanMap: [String: Int] = ["IV": 4,
                                      "IX": 9,
                                      "XL": 40,
                                      "XC": 90,
                                      "CD": 400,
                                      "CM": 900]

func romanToInt(_ s: String) -> Int {
    var result = 0
    
    var temp = s
    doublesRomanMap.forEach{
        temp = temp.replacingOccurrences(of: $0.key, with: "\($0.value)_")
    }
    
    singlesRomanMap.forEach{
        temp = temp.replacingOccurrences(of: $0.key, with: "\($0.value)_")
    }
    print(temp)
    let split = temp.split(separator: "_")
    
    split.forEach{ result += Int($0)! }
    
    return result
}

romanToInt("MCMXCIV")

/*********************************************************/

func longestCommonPrefix(_ strs: [String]) -> String {
    
    var temp = strs.sorted{ $0.count < $1.count }
    let small = Array(temp.first ?? "")
    
    var prefix = ""
    
    label: for i in 0..<small.count {
        
        for s in 1..<temp.count{
            let arr = Array(temp[s])
            if small[i] != arr[i] {break label}
        }
        prefix += "\(small[i])"
    }
    
    return prefix
}

longestCommonPrefix(["flower","flow","flight"])

/*********************************************************/

/*********************************************************/
